import { create } from 'zustand';
import { I18nManager } from 'react-native';
import i18n, { RTL_LANGUAGES } from '../i18n';

class MockMMKV {
  private map = new Map<string, any>();
  set(key: string, value: any) { this.map.set(key, value); }
  getString(key: string) { return this.map.get(key) as string | undefined; }
  getBoolean(key: string) { return this.map.get(key) as boolean | undefined; }
  getNumber(key: string) { return this.map.get(key) as number | undefined; }
  delete(key: string) { this.map.delete(key); }
  clearAll() { this.map.clear(); }
}
const storage = new MockMMKV();

interface SettingsState {
  theme: 'dark' | 'light' | 'system';
  language: string;
  biometricEnabled: boolean;
  notificationsEnabled: boolean;
  apiUrl: string;
  setTheme: (theme: 'dark' | 'light' | 'system') => void;
  setLanguage: (lang: string) => void;
  setBiometric: (val: boolean) => void;
  setNotifications: (val: boolean) => void;
  setApiUrl: (url: string) => void;
  loadSettings: () => void;
}

export const useSettingsStore = create<SettingsState>((set) => ({
  theme: (storage.getString('theme') as 'dark' | 'light' | 'system') ?? 'dark',
  language: storage.getString('language') ?? i18n.language ?? 'en',
  biometricEnabled: storage.getBoolean('biometric') ?? false,
  notificationsEnabled: storage.getBoolean('notifications') ?? true,
  apiUrl: storage.getString('apiUrl') ?? 'https://freeplanbaby.alwaysdata.net',

  setTheme: (theme) => {
    storage.set('theme', theme);
    set({ theme });
  },

  setLanguage: (lang) => {
    storage.set('language', lang);
    i18n.changeLanguage(lang);
    const isRTL = RTL_LANGUAGES.includes(lang);
    if (I18nManager.isRTL !== isRTL) {
      I18nManager.forceRTL(isRTL);
      // App will reload on next launch to apply RTL
    }
    set({ language: lang });
  },

  setBiometric: (val) => {
    storage.set('biometric', val);
    set({ biometricEnabled: val });
  },

  setNotifications: (val) => {
    storage.set('notifications', val);
    set({ notificationsEnabled: val });
  },

  setApiUrl: (url) => {
    storage.set('apiUrl', url);
    set({ apiUrl: url });
  },

  loadSettings: () => {
    const lang = storage.getString('language');
    if (lang) i18n.changeLanguage(lang);
  },
}));
