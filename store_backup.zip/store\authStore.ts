import { create } from 'zustand';

class MockMMKV {
  private map = new Map<string, any>();
  set(key: string, value: any) { this.map.set(key, value); }
  getString(key: string) { return this.map.get(key) as string | undefined; }
  getBoolean(key: string) { return this.map.get(key) as boolean | undefined; }
  getNumber(key: string) { return this.map.get(key) as number | undefined; }
  delete(key: string) { this.map.delete(key); }
  clearAll() { this.map.clear(); }
}
const storage = new MockMMKV();

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: 'admin' | 'agent';
  agency_name?: string;
  status: 'active' | 'pending' | 'restricted';
  permission: 'full' | 'view_only' | 'restricted';
  avatar?: string;
}

interface AuthState {
  token: string | null;
  user: User | null;
  isAuthenticated: boolean;
  setAuth: (token: string, user: User) => void;
  clearAuth: () => void;
  updateUser: (user: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token: storage.getString('token') ?? null,
  user: (() => {
    const raw = storage.getString('user');
    return raw ? JSON.parse(raw) : null;
  })(),
  isAuthenticated: !!storage.getString('token'),

  setAuth: (token, user) => {
    storage.set('token', token);
    storage.set('user', JSON.stringify(user));
    set({ token, user, isAuthenticated: true });
  },

  clearAuth: () => {
    storage.delete('token');
    storage.delete('user');
    set({ token: null, user: null, isAuthenticated: false });
  },

  updateUser: (partial) => {
    set((state) => {
      const updated = state.user ? { ...state.user, ...partial } : null;
      if (updated) storage.set('user', JSON.stringify(updated));
      return { user: updated };
    });
  },
}));
